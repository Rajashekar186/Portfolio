﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PortfolioManagementSystem_API.Migrations
{
    public partial class Portfolio2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "FIMaster",
                columns: table => new
                {
                    FID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FIName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FIDescription = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    RateOfIntrest = table.Column<int>(type: "int", nullable: false),
                    Tenure = table.Column<int>(type: "int", nullable: false),
                    PurchaseUnitValue = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FIMaster", x => x.FID);
                });

            migrationBuilder.CreateTable(
                name: "MFMaster",
                columns: table => new
                {
                    MFId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MFName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FundHouse = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FaceValue = table.Column<int>(type: "int", nullable: false),
                    NAVvalue = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MFMaster", x => x.MFId);
                });

            migrationBuilder.CreateTable(
                name: "StockMaster",
                columns: table => new
                {
                    StockId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StockName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FaceValue = table.Column<int>(type: "int", nullable: false),
                    StockPrice = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StockMaster", x => x.StockId);
                });

            migrationBuilder.CreateTable(
                name: "UserFI",
                columns: table => new
                {
                    TransactionNo = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FId = table.Column<int>(type: "int", nullable: true),
                    FIMasterFID = table.Column<int>(type: "int", nullable: true),
                    PurchaseDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    PurchaseQty = table.Column<int>(type: "int", nullable: false),
                    TotalAmount = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserFI", x => x.TransactionNo);
                    table.ForeignKey(
                        name: "FK_UserFI_FIMaster_FIMasterFID",
                        column: x => x.FIMasterFID,
                        principalTable: "FIMaster",
                        principalColumn: "FID");
                });

            migrationBuilder.CreateTable(
                name: "DailyMFNAVs",
                columns: table => new
                {
                    RecordNo = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MFId = table.Column<int>(type: "int", nullable: true),
                    MFMasterMFId = table.Column<int>(type: "int", nullable: true),
                    Date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ClosingPrice = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DailyMFNAVs", x => x.RecordNo);
                    table.ForeignKey(
                        name: "FK_DailyMFNAVs_MFMaster_MFMasterMFId",
                        column: x => x.MFMasterMFId,
                        principalTable: "MFMaster",
                        principalColumn: "MFId");
                });

            migrationBuilder.CreateTable(
                name: "UserMF",
                columns: table => new
                {
                    MFTransactionNo = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MFId = table.Column<int>(type: "int", nullable: true),
                    MFMasterMFId = table.Column<int>(type: "int", nullable: true),
                    QuantityPrice = table.Column<int>(type: "int", nullable: false),
                    PurchaseDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    PurchasedQuantity = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserMF", x => x.MFTransactionNo);
                    table.ForeignKey(
                        name: "FK_UserMF_MFMaster_MFMasterMFId",
                        column: x => x.MFMasterMFId,
                        principalTable: "MFMaster",
                        principalColumn: "MFId");
                });

            migrationBuilder.CreateTable(
                name: "DailyStockPrices",
                columns: table => new
                {
                    RecordNo = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StockId = table.Column<int>(type: "int", nullable: true),
                    StockMasterStockId = table.Column<int>(type: "int", nullable: true),
                    Date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ClosingPrice = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DailyStockPrices", x => x.RecordNo);
                    table.ForeignKey(
                        name: "FK_DailyStockPrices_StockMaster_StockMasterStockId",
                        column: x => x.StockMasterStockId,
                        principalTable: "StockMaster",
                        principalColumn: "StockId");
                });

            migrationBuilder.CreateTable(
                name: "MyStocks",
                columns: table => new
                {
                    TransactionId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StockId = table.Column<int>(type: "int", nullable: true),
                    StockMasterStockId = table.Column<int>(type: "int", nullable: true),
                    Quantity = table.Column<int>(type: "int", nullable: false),
                    PurchaseDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    PurchasePrice = table.Column<double>(type: "float", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MyStocks", x => x.TransactionId);
                    table.ForeignKey(
                        name: "FK_MyStocks_StockMaster_StockMasterStockId",
                        column: x => x.StockMasterStockId,
                        principalTable: "StockMaster",
                        principalColumn: "StockId");
                });

            migrationBuilder.CreateIndex(
                name: "IX_DailyMFNAVs_MFMasterMFId",
                table: "DailyMFNAVs",
                column: "MFMasterMFId");

            migrationBuilder.CreateIndex(
                name: "IX_DailyStockPrices_StockMasterStockId",
                table: "DailyStockPrices",
                column: "StockMasterStockId");

            migrationBuilder.CreateIndex(
                name: "IX_MyStocks_StockMasterStockId",
                table: "MyStocks",
                column: "StockMasterStockId");

            migrationBuilder.CreateIndex(
                name: "IX_UserFI_FIMasterFID",
                table: "UserFI",
                column: "FIMasterFID");

            migrationBuilder.CreateIndex(
                name: "IX_UserMF_MFMasterMFId",
                table: "UserMF",
                column: "MFMasterMFId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "DailyMFNAVs");

            migrationBuilder.DropTable(
                name: "DailyStockPrices");

            migrationBuilder.DropTable(
                name: "MyStocks");

            migrationBuilder.DropTable(
                name: "UserFI");

            migrationBuilder.DropTable(
                name: "UserMF");

            migrationBuilder.DropTable(
                name: "StockMaster");

            migrationBuilder.DropTable(
                name: "FIMaster");

            migrationBuilder.DropTable(
                name: "MFMaster");
        }
    }
}
