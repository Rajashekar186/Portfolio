﻿using System.ComponentModel.DataAnnotations;

namespace PortfolioManagementSystem_API.Models
{
    public class FixedIncomeMaster
    {
        [Key]

        public int FID { get; set; }

        public string FIName { get; set; }

        public string FIDescription { get; set; }

        public int RateOfIntrest { get; set; }

        public int Tenure { get; set; }

        public int PurchaseUnitValue { get; set; }


    }
}
