﻿using System.ComponentModel.DataAnnotations;

namespace PortfolioManagementSystem_API.Models
{
    public class LoginViewModel
    {
       
        public string Email { get; set; }
        public string Password { get; set; }

    }
}
