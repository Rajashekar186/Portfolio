﻿using System.ComponentModel.DataAnnotations;
using System.Numerics;

namespace PortfolioManagementSystem_API.Models
{
    public class User
    {
        [Key]
        public int LoginId { get; set; }
        public string Email { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DOB { get; set; }
        public int Age { get; set; }
        public string Gender { get; set; }
        public string Address { get; set; }
        public ulong PhoneNumber { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
        public string City { get; set; }
        public int Pincode { get; set; }

    }
}
