﻿using System.ComponentModel.DataAnnotations;

namespace PortfolioManagementSystem_API.Models
{
    public class DailyStockPrice
    {
        [Key]

        public int RecordNo { get; set; }

        public int? StockId { get; set; }

        public virtual StockMaster? StockMaster { get; set; }

        public DateTime Date { get; set; }

        public int ClosingPrice { get; set; }
    }
}
