﻿using System.ComponentModel.DataAnnotations;

namespace PortfolioManagementSystem_API.Models
{
    public class Stocks
    {
        [Key]

        public int TransactionId { get; set; }

        public int? StockId { get; set; }

        public virtual StockMaster? StockMaster { get; set; }

        public int Quantity { get; set; }

        public DateTime PurchaseDate { get; set; }

        public double PurchasePrice { get; set; }
    }
}
