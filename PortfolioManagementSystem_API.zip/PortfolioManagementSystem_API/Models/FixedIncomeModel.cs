﻿using System.ComponentModel.DataAnnotations;

namespace PortfolioManagementSystem_API.Models
{
    public class FixedIncomeModel
    {
        [Key]

        public int TransactionNo { get; set; }

        public int? FId { get; set; }

        public virtual FixedIncomeMaster? FIMaster { get; set; }

        public DateTime PurchaseDate { get; set; }

        public int PurchaseQty { get; set; } //ex:5

        public int TotalAmount { get; set; } // ex:5*1000=5000
    }
}
