﻿using System.ComponentModel.DataAnnotations;

namespace PortfolioManagementSystem_API.Models
{
    public class DailyMFNAVModel
    {
        [Key]

        public int RecordNo { get; set; }

        public int? MFId { get; set; }

        public virtual MFMaster? MFMaster { get; set; }

        public DateTime Date { get; set; }

        public int ClosingPrice { get; set; }
    }
}
