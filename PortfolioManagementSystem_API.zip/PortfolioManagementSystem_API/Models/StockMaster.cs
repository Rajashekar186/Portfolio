﻿using System.ComponentModel.DataAnnotations;

namespace PortfolioManagementSystem_API.Models
{
    public class StockMaster
    {
        [Key]

        public int StockId { get; set; }

        public string StockName { get; set; }

        public int FaceValue { get; set; }
        public int StockPrice { get; set; }
    }
}
