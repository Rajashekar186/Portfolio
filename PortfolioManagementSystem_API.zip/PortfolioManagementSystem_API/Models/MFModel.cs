﻿using System.ComponentModel.DataAnnotations;

namespace PortfolioManagementSystem_API.Models
{
    public class MFModel
    {
        [Key]

        public int MFTransactionNo { get; set; }

        public int? MFId { get; set; }

        public virtual MFMaster? MFMaster { get; set; }

        public int QuantityPrice { get; set; }

        public DateTime PurchaseDate { get; set; }

        public int PurchasedQuantity { get; set; }
    }
}
