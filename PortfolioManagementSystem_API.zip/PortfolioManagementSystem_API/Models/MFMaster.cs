﻿using System.ComponentModel.DataAnnotations;

namespace PortfolioManagementSystem_API.Models
{
    public class MFMaster
    {
        [Key]

        public int MFId { get; set; }

        public string MFName { get; set; }

        public string FundHouse { get; set; }

        public int FaceValue { get; set; }

        public int NAVvalue { get; set; }
    }
}
