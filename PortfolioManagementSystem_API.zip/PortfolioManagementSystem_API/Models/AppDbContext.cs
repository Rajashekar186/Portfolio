﻿using Microsoft.EntityFrameworkCore;

namespace PortfolioManagementSystem_API.Models
{
    public class AppDbContext:DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {

        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.HasSequence("CustSequence")

     .StartsAt(100).IncrementsBy(1);

            modelBuilder.Entity<User>()

             .Property(c => c.LoginId)

             .HasDefaultValueSql("NEXT VALUE FOR CustSequence");

            base.OnModelCreating(modelBuilder);


        }



        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<StockMaster> StockMaster { get; set; }

        public virtual DbSet<Stocks> MyStocks { get; set; }

        public virtual DbSet<MFMaster> MFMaster { get; set; }

        public virtual DbSet<MFModel> UserMF { get; set; }

        public virtual DbSet<FixedIncomeMaster> FIMaster { get; set; }

        public virtual DbSet<FixedIncomeModel> UserFI { get; set; }

        public virtual DbSet<DailyStockPrice> DailyStockPrices { get; set; }

        public virtual DbSet<DailyMFNAVModel> DailyMFNAVs { get; set; }

    }
}

