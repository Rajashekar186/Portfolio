﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PortfolioManagementSystem_API.Models;

namespace PortfolioManagementSystem_API.Controllers
{ 

[Route("api/[controller]")]
[ApiController]
public class AdminController : ControllerBase
{
    AppDbContext db = null;

    public AdminController(AppDbContext context)

    {

        this.db = context;

    }
    [HttpPost]

    [Route("AdminLogin")]

    public IActionResult AdminLogin([FromBody] LoginViewModel aLog)

    {

        if (aLog.Email == null || aLog.Password == null)

        {

            return BadRequest();

        }

        if (aLog.Email == "admin@gmail.com" && aLog.Password == "admin")

        {

            return Ok("Admin Login successfull !!");

        }

        return BadRequest("Admin details doesn't exist!!");

    }
    [HttpGet]

    public IActionResult GetList()

    {

        return Ok(db.Users.ToList());

    }

    [HttpGet]

    [Route("{id}")]

    public IActionResult GetById(int id)

    {

        try

        {

            var customer = db.Users.Find(id);

            return Ok(customer);

        }

        catch (Exception ex)

        {

            throw ex;

        }

    }
    [HttpPut]

    [Route("{id}")]

    public IActionResult UpdateCustomerDetails([FromBody] UserModel investor, int id)

    {

        if (id == null)

        {

            return BadRequest();

        }

        var investorToBeUpdated = db.Users.Find(id);

        if (investorToBeUpdated.LoginId == id)

        {
            investorToBeUpdated.FirstName = investor.FirstName;

            investorToBeUpdated.LastName = investor.LastName;

            investorToBeUpdated.DOB = investor.DOB;
            investorToBeUpdated.Address = investor.Address;
            investorToBeUpdated.City = investor.City;
            investorToBeUpdated.State = investor.State;
            investorToBeUpdated.Country = investor.Country;
            investorToBeUpdated.Pincode = investor.Pincode;
            investorToBeUpdated.PhoneNumber = investor.PhoneNumber;
            investorToBeUpdated.Email = investor.Email;
            investorToBeUpdated.Gender = investor.Gender;


            db.Users.Update(investorToBeUpdated);

            db.SaveChanges();

            return Ok("investor details Updated successfully !!");

        }

        return BadRequest("Invalid Customer Details...");

    }
    [HttpDelete]

    [Route("{id}")]

    public IActionResult DeleteUser(int id)

    {

        if (id == null)

        {

            return BadRequest();

        }

        var userToBeDeleted = db.Users.Find(id);

        if (userToBeDeleted != null)

        {

            db.Users.Remove(userToBeDeleted);

            db.SaveChanges();

            return Ok("User Deleted successfully !!");

        }

        return BadRequest("User  details doesn't exist!!");

    }
       
        
        
        [HttpPost]


        [Route("AddCustomer")]

        public IActionResult AddCustomer([FromBody] User userObj)

        {

            if (userObj == null)

            {

                return BadRequest();

            }

            if (ModelState.IsValid)

            {

                User customer = new User();

                customer.FirstName = userObj.FirstName;

                customer.LastName = userObj.LastName;

                customer.DOB = userObj.DOB;

                customer.Gender = userObj.Gender;

                customer.Address = userObj.Address;

                customer.City = userObj.City;

                customer.State = userObj.State;

                customer.Country = userObj.Country;

                customer.PhoneNumber = userObj.PhoneNumber;

                customer.Email = userObj.Email;

                customer.Pincode = userObj.Pincode;

                db.Users.Add(customer);

                db.SaveChanges();

                return Ok("User Registration Successfull !!");

            }

            return BadRequest("Invalid Registration .. ");

        }

    }

}



      
   




