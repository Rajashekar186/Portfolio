﻿using System.ComponentModel.DataAnnotations;

namespace PortFolioManagementSystem_MVC.Models
{
    public class LoginModel
    {
        [Required]
        public string Email { get; set; }

        [Required]
        [DataType(DataType.Password)]

        public string Password { get; set; }
    }
}
